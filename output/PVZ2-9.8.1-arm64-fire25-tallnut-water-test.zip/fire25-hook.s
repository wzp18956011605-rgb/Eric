ldr x8, [x19, #0x238]
ldrb w9, [x8]
cbz w9, restore
ldur s0, [x29, #-0xe0]
fmov s1, #1.25
fmul s0, s0, s1
stur s0, [x29, #-0xe0]
restore:
ldr x8, [x19, #0x250]
b #13142452
