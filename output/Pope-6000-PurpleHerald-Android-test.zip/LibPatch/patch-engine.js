/* Offline native-library patcher: no uploads, requests, or external dependencies. */
(function (scope) {
  async function digest(bytes) {
    const hash = await scope.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(hash), v => v.toString(16).padStart(2, '0')).join('');
  }
  function decodeHex(hex) {
    return Uint8Array.from(hex.match(/../g), p => parseInt(p, 16));
  }
  async function patchLibrary(input, recipe) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    if (bytes.length !== recipe.file_size || bytes[0] !== 127 || bytes[1] !== 69 || bytes[2] !== 76 || bytes[3] !== 70 || bytes[4] !== 2 || bytes[5] !== 1) throw new Error('文件不是本补丁支持的 64 位 ELF 库，未作任何修改。');
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (view.getUint16(18, true) !== 183) throw new Error('需要 arm64-v8a 库，不能使用 x86 或 armeabi-v7a 库。');
    const pc = recipe.function_offset;
    if (await digest(bytes.subarray(pc, pc + recipe.function_length)) !== recipe.function_sha256) throw new Error('豌豆薄荷函数校验不匹配：可能是其他版本或已有冲突补丁。请把当前库压成 ZIP 提供，不能强行套用。');
    const payload = Uint8Array.from(atob(recipe.payload_base64), c => c.charCodeAt(0));
    if (recipe.cave_offset + payload.length > recipe.cave_limit) throw new Error('补丁区域超界。');
    if (bytes.subarray(recipe.cave_offset, recipe.cave_offset + payload.length).some(v => v !== 0)) throw new Error('预留区域已被其他修改占用，已停止以保护原库。');
    const previousSize = Number(view.getBigUint64(recipe.rx_size_offset, true));
    const previousMemory = Number(view.getBigUint64(recipe.rx_memsize_offset, true));
    if (previousSize < recipe.minimum_rx_size || previousSize > recipe.maximum_previous_rx_size || previousMemory !== previousSize) throw new Error('ELF 可执行段布局不匹配，未生成输出。');
    const output = bytes.slice();
    output.set(decodeHex(recipe.new_entry), pc);
    output.set(payload, recipe.cave_offset);
    const resultView = new DataView(output.buffer);
    const newSize = BigInt(recipe.cave_offset + payload.length);
    resultView.setBigUint64(recipe.rx_size_offset, newSize, true);
    resultView.setBigUint64(recipe.rx_memsize_offset, newSize, true);
    return {bytes: output, input_sha256: await digest(bytes), output_sha256: await digest(output)};
  }
  scope.patchSweetpeaLibrary = patchLibrary;
  if (typeof module !== 'undefined') module.exports = {patchLibrary};
})(globalThis);
