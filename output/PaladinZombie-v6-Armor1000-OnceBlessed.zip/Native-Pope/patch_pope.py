from pathlib import Path
import struct,hashlib,base64,sys
RECIPE = {'file_size': 40569072, 'machine': 183, 'function_offset': 11796460, 'function_length': 2180, 'function_sha256': '087247d765ec69fbc14b714c57917e4466d4d47792a4f94d7fd40f9aed339b48', 'site': 11797548, 'old_call': 'd3020594', 'new_call': '352d6594', 'cave_offset': 38320384, 'cave_limit': 38320832, 'payload_base64': 'P0AAcUAAAFSc1Z8X81O+qf4LAPnzAwCq9AMfquADE6qBBgAQsuGfl6ACADXgAxOqwQYAEK7hn5cgAgA14AMTquEDHyo345+X4AMTqqEGABCU4J+X9AMAqiABALQoAIBSCNQAOeADE6qBBgAQjeCfl+ADE6rhBgAQiuCfl+ADFKr+C0D581PCqMADX9bze76p8wMAquADE6rBAgAQlOGfl8ABADXgAxOqAQMAEJDhn5dAAQA14AMUqlrNmpcIQEK5H0EAceAAAFTgAxOq4QQAEIfhn5cEAAAUIACAUgIAABTgAx8q83vCqMADX9YAAAAAFlBhbGFkaW5TdWl0AAAAAAAAAAAAAAAAFlBhbGFkaW5IZWxtAAAAAAAAAAAAAAAAHkRhcmtHaWx0RGVmYXVsdAAAAAAAAAAAJFBhbGFkaW5TdWl0RGVmYXVsdAAAAAAAJFBvcGVCbGVzc2VkRGVmYXVsdAAAAAAACkNyb3duAAAAAAAAAAAAAAAAAAAAAAAA', 'payload_length': 384, 'minimum_rx_size': 38318716, 'rx_size_offset': 96, 'rx_memsize_offset': 104, 'armor_alias': 'DarkGiltDefault', 'target_helm_enum': 16, 'native_clear_helm': 13125152, 'native_add_armor': 13122464, 'runtime_tested': False, 'upgrade_from_payloads': ['P0AAcUAAAFSc1Z8X83u8qfMDAKoBCIBSQuOfl/9/Aan/EwD5yAOAUuhDADmoAQAQCSlAqekTAfjqkwH44AMTquFDAJGX4J+XYAAAtCgAgFII1AA583vEqMADX9YAAAAARGFya0dpbHREZWZhdWx0AA==', 'P0AAcUAAAFSc1Z8X81O6qf4LAPnzAwCqAQiAUkHjn5f/fwKp/xsA+cgDgFLogwA5CAUAEAkpQKnpEwL46pMC+OADE6rhgwCRluCfl/QDAKqAAwC0KACAUgjUADn/fwKp/xsA+UgDgFLogwA5qAMAEAkpQKnpEwL46pMC+OADE6rhgwCRmuGfl8ABADX/fwKp/xsA+YgEgFLogwA5qAIAEAkpQKnpEwL46pMC+AsRQLnrEwO44AMTquGDAJF54J+X4AMUqv4LQPnzU8aowANf1kRhcmtHaWx0RGVmYXVsdABTaG91bGRlckFybW9yAAAAUGFsYWRpblN1aXREZWZhdWx0AAAAAAAA', 'P0AAcUAAAFSc1Z8X81O+qf4LAPnzAwCq9AMfquADE6qBBQAQsuGflyACADXgAxOq4QMfKjvjn5fgAxOqYQUAEJjgn5f0AwCqIAEAtCgAgFII1AA54AMTqkEFABCR4J+XyHKoUmh6AblofgG54AMUqv4LQPnzU8KowANf1vN7vqnzAwCq4AMTqkECABCY4Z+XQAEANeADFKpizZqXCEBCuR9BAHHgAABU4AMTqmEDABCP4Z+XBAAAFCAAgFICAAAU4AMfKvN7wqjAA1/WAAAAABZQYWxhZGluU3VpdAAAAAAAAAAAAAAAAB5EYXJrR2lsdERlZmF1bHQAAAAAAAAAACRQYWxhZGluU3VpdERlZmF1bHQAAAAAAApDcm93bgAAAAAAAAAAAAAAAAAAAAAAAA==', 'P0AAcUAAAFSc1Z8X81O8qfULAPn+DwD58wMAqvQDH6rgAxOq4QYAELHhn5dgAwA14AMTquEDHyo645+X4AMTqsEGABCX4J+X9AMAqmACALQoAIBSCNQAOcgGABAJKUCpCwlA+ekrAqnrGwD5NQiAUvWzADngAxOq4YMAkYngn5e1BgARv1YBcUH//1TIcqhSaHoBuWh+AbngAxSq9QtA+f4PQPnzU8SowANf1vN7vqnzAwCq4AMTqkECABCM4Z+XQAEANeADFKpWzZqXCEBCuR9BAHHgAABU4AMTqmEDABCD4Z+XBAAAFCAAgFICAAAU4AMfKvN7wqjAA1/WAAAAABZQYWxhZGluU3VpdAAAAAAAAAAAAAAAAB5EYXJrR2lsdERlZmF1bHQAAAAAAAAAABhQYWxhZGluU3VpdEEAAAAAAAAAAAAAAApDcm93bgAAAAAAAAAAAAAAAAAAAAAAAA==', 'P0AAcUAAAFSc1Z8X81O+qf4LAPnzAwCq9AMfquADE6oBBgAQsuGfl0ACADXgAxOqQQYAEK7hn5fAAQA14AMTquEDHyo345+X4AMTqiEGABCU4J+X9AMAqsAAALQoAIBSCNQAOeADE6oBBgAQjeCfl+ADFKr+C0D581PCqMADX9bze76p8wMAquADE6qhAgAQl+Gfl8ABADXgAxOq4QIAEJPhn5dAAQA14AMUql3NmpcIQEK5H0EAceAAAFTgAxOqAQQAEIrhn5cEAAAUIACAUgIAABTgAx8q83vCqMADX9YWUGFsYWRpblN1aXQAAAAAAAAAAAAAAAAWUGFsYWRpbkhlbG0AAAAAAAAAAAAAAAAeRGFya0dpbHREZWZhdWx0AAAAAAAAAAAkUGFsYWRpblN1aXREZWZhdWx0AAAAAAAKQ3Jvd24AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'], 'native_has_armor': 13123564, 'body_cosmetic_no_damage_absorption': False, 'version': 6, 'secondary_sites': [{'site': 11795424, 'old_call': '03110594', 'new_call': '6b2f6594', 'function_offset': 11795308, 'function_length': 1152, 'function_sha256': 'caf2ac4f4837e782b4bee53108f18833318dd9322ce354f757f8517f1aea4543', 'upgrade_calls': ['672f6594', '732f6594', '682f6594']}], 'body_hp': 190, 'current_health_offset': 376, 'max_health_offset': 380, 'guard_entry': 38320524, 'pope_can_upgrade_knight': True, 'clear_existing_armor_mask': 0, 'body_armor_hp': 1000, 'preserve_original_body_health': True, 'body_armor_component_count': 1, 'body_armor_alias': 'PaladinSuitDefault', 'body_armor_type': 'PaladinSuit', 'helmet_hp': 1600, 'permanent_blessing_marker_alias': 'PopeBlessedDefault', 'permanent_marker_armor_type': 'PaladinSuit', 'permanent_marker_absorbs_damage': False}
def patch_bytes(b):
 r=RECIPE
 if len(b)!=r['file_size'] or b[:6]!=bytes([127,69,76,70,2,1]) or struct.unpack_from('<H',b,18)[0]!=183:raise ValueError('仅支持对应arm64-v8a ELF库')
 old=bytes.fromhex(r['old_call']);new=bytes.fromhex(r['new_call']);payload=base64.b64decode(r['payload_base64']);applied=b[r['site']:r['site']+4]==new
 if not applied and b[r['site']:r['site']+4]!=old:raise ValueError('调用点不匹配')
 check=bytearray(b[r['function_offset']:r['function_offset']+r['function_length']]);off=r['site']-r['function_offset'];check[off:off+4]=old
 if hashlib.sha256(check).hexdigest()!=r['function_sha256']:raise ValueError('国王函数校验不匹配')
 extra_applied=True
 for q in r.get('secondary_sites',[]):
  a=bytes.fromhex(q['old_call']);n=bytes.fromhex(q['new_call']);cur=b[q['site']:q['site']+4]
  if cur not in [a,n]+[bytes.fromhex(c) for c in q.get('upgrade_calls',[])]:raise ValueError('加冕判定调用点不匹配')
  extra_applied=extra_applied and cur==n;fn=bytearray(b[q['function_offset']:q['function_offset']+q['function_length']]);off=q['site']-q['function_offset'];fn[off:off+4]=a
  if hashlib.sha256(fn).hexdigest()!=q['function_sha256']:raise ValueError('加冕判定函数校验不匹配')
 rx=struct.unpack_from('<Q',b,r['rx_size_offset'])[0];mem=struct.unpack_from('<Q',b,r['rx_memsize_offset'])[0]
 if rx!=mem or rx<r['minimum_rx_size']:raise ValueError('ELF可执行段布局不匹配')
 if applied:
  if b[r['cave_offset']:r['cave_offset']+len(payload)]==payload and extra_applied and rx>=r['cave_offset']+len(payload):return b
  compatible=b[r['cave_offset']:r['cave_offset']+len(payload)]==payload
  for candidate in r.get('upgrade_from_payloads',[]):
   prev=base64.b64decode(candidate);cave=b[r['cave_offset']:r['cave_offset']+len(payload)]
   if rx>=r['cave_offset']+len(prev) and cave[:len(prev)]==prev and not any(cave[len(prev):]):compatible=True;break
  if not compatible:raise ValueError('已有补丁不一致，停止修改')
 elif rx>r['cave_offset'] or any(b[r['cave_offset']:r['cave_offset']+len(payload)]):raise ValueError('预留区被占用，停止修改')
 out=bytearray(b);out[r['site']:r['site']+4]=new;out[r['cave_offset']:r['cave_offset']+len(payload)]=payload
 for q in r.get('secondary_sites',[]):out[q['site']:q['site']+4]=bytes.fromhex(q['new_call'])
 for off in [r['rx_size_offset'],r['rx_memsize_offset']]:struct.pack_into('<Q',out,off,max(rx,r['cave_offset']+len(payload)))
 return bytes(out)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('用法: python patch_pope.py 当前libPVZ2.so 输出libPVZ2.so')
 src,dst=map(Path,sys.argv[1:]);assert src.resolve()!=dst.resolve(),'请选择另一个输出路径保留原库';data=patch_bytes(src.read_bytes());dst.write_bytes(data);print('校验通过，输出SHA256:',hashlib.sha256(data).hexdigest())
