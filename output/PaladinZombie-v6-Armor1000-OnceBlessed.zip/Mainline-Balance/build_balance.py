from pathlib import Path
import sys,json,zipfile,copy,struct,hashlib
sys.path[:0]=['/workspace/pvz-tools','/workspace/pvz-tools/python-deps']
from rsgp_codec import read_packet,packet,table_entries,lookup
from decode_rton import Decoder
from encode_rton import encode
from pam_codec import Reader
W=Path('/workspace/plant-batch');O=Path('/workspace/pvz-original/extracted/main.713.com.ea.game.pvz2_row.obb.dir');root=Path('/workspace/Eric/output');src=root/'PaladinZombie-v5-PopePortrait-EarlyWaves.zip';out=root/'PaladinZombie-v5-Mainline-Balance-Update.zip'
with zipfile.ZipFile(src) as z:files={n:z.read(n) for n in z.namelist()}
before=files.copy();pk='Overlay/Packet/Packages.rsgp';p=read_packet(files[pk]);oldp=p.copy()
def dec(b):return Decoder(b).obj()
def find(d,a):return next(o['objdata'] for o in d['objects'] if a in o.get('aliases',[]))
sheets={s:dec(p['PACKAGES\\'+s+'.RTON']) for s in ['PLANTPROPERTIES','PLANTLEVELS','PROJECTILETYPES','POWERS','ARMORTYPES','ZOMBIEPROPERTIES']};original=copy.deepcopy(sheets);P=sheets['PLANTPROPERTIES'];L=sheets['PLANTLEVELS'];PR=sheets['PROJECTILETYPES'];PW=sheets['POWERS'];report={'base':src.name,'changes':[],'runtime_tested':False}
def prop(alias,k,v):
 obj=find(P,alias);report['changes'].append({'plant':alias,'field':k,'before':obj.get(k),'after':v});obj[k]=v

def level(name,field,value,sub=None):
 obj=find(L,name);matched=[x for x in obj['FloatStats'] if x.get('Name')==field and (sub is None or x.get('SubType')==str(sub))]
 if not matched:
  x={'Name':field,'Values':[value]*obj['LevelCap']}
  if sub is not None:x['SubType']=str(sub)
  obj['FloatStats'].append(x)
 else:
  for x in matched:x['Values']=[value]*max(len(x['Values']),obj['LevelCap'])

def stat(name,alias,k,value,levelname=None):prop(alias,k,value);level(name,levelname or k,value)
def action(name,alias,index,minimum,maximum=None):
 a=find(P,alias)['Actions'][index];a['CooldownTimeMin']=minimum;a['CooldownTimeMax']=minimum if maximum is None else maximum
 level(name,'ActionCooldownMin',minimum,index);level(name,'ActionCooldownMax',minimum if maximum is None else maximum,index)
 report['changes'].append({'plant':name,'action':index,'interval':[a['CooldownTimeMin'],a['CooldownTimeMax']]})
def damage(name,alias,index,value):
 a=find(P,alias)['Actions'][index]
 if 'Damage' in a:a['Damage']=value
 for x in find(L,name)['FloatStats']:
  if x.get('SubType')==str(index) and (x.get('Type')=='ActionDamage' or x.get('Name','').startswith('ActionDamage')):
   x['Values']=[value]*max(len(x['Values']),find(L,name)['LevelCap']);break
 else:level(name,'ActionDamage',value,index)
 if a.get('Projectile'):
  ref=a['Projectile'].split('(')[1].split('@')[0]
  # Clone shared ammunition before changing it, so unrelated plants are untouched.
  newalias=name.title()+'BalanceShot'+str(index);template=next(o for o in PR['objects'] if ref in o.get('aliases',[]));new=copy.deepcopy(template);new['aliases']=[newalias];new['objdata']['BaseDamage']=value;PR['objects'].append(new);a['Projectile']='RTID('+newalias+'@ProjectileTypes)'
 report['changes'].append({'plant':name,'action':index,'damage':value})
# Costs explicitly requested in this batch are fixed across levels.
for args in [('bloomerang','BloomerangDefault',200),('magnetshroom','MagnetShroomDefault',75),('hypnoshroom','HypnoShroomDefault',75),('bowlingbulb','BowlingBulbDefault',250),('banana','BananaDefault',800),('endurian','EndurianDefault',175),('stallia','StalliaDefault',50),('primalwallnut','PrimalWallnutDefault',100)]:stat(args[0],args[1],'Cost',args[2])
action('cabbagepult','CabbagepultDefault',0,2.5)
# Ordinary and shadow forms share the requested damage; no plant-food changes.
damage('shadowpeashooter','ShadowPeashooterDefault',0,30);damage('shadowpeashooter','ShadowPeashooterDefault',1,30)
stat('shadowpeashooter','ShadowPeashooterDefault','PoweredAttackSlowDuration',5.0,'ShadowPeashooter_PoweredAttackSlowDuration');stat('shadowpeashooter','ShadowPeashooterDefault','PoweredAttackSlowMinimumDuration',5.0,'ShadowPeashooter_PoweredAttackSlowMinimumDuration');stat('shadowpeashooter','ShadowPeashooterDefault','PoweredAttackDecayPerZombieHit',0.0,'ShadowPeashooter_PoweredAttackDecayPerZombieHit')
damage('splitpea','SplitpeaDefault',0,25);damage('splitpea','SplitpeaDefault',1,30)
damage('laser_bean','LaserBeanDefault',0,40);action('laser_bean','LaserBeanDefault',0,1.8)
stat('powerplant','PowerPlantDefault','NumberOfFreeTiles',1,'TileTurnip_NumberOfFreeTiles');stat('powerplant','PowerPlantDefault','FirstNonFreeCost',100,'TileTurnip_FirstNonFreeCost');stat('powerplant','PowerPlantDefault','CostMultiplier',2.0,'TileTurnip_CostMultiplier')
for o in PW['objects']:
 d=o['objdata'];name=d.get('TypeName','')
 if name.startswith('SunshroomGrowthLevel'):
  for stage in d['GrowthStages']:stage['TimeToGrowInSeconds']=40
 if name.startswith('PrimalPotatoMineDamageLvl'):
  d['DamageRadius']['RadiusInGridSquareWidths']=2.6;d['DamageRadius']['DamageProps']['BaseDamage']=1000
report['sunshroom_all_growth_stage_waits']=40
stat('sunbean','SunBeanDefault','SunPerHitpoint',0.5,'Sunbean_SunPerHitpoint');stat('sunbean','SunBeanDefault','MaxSunPerZombie',300,'Sunbean_MaxSunPerZombie')
prop('HotPotatoDefault','BlockMeltingDuration',2.0)
damage('endurian','EndurianDefault',0,30)
action('celerystalker','CeleryStalkerDefault',0,1.0);damage('celerystalker','CeleryStalkerDefault',0,100);prop('CeleryStalkerDefault','RetractionDelay',1.5)
# Rectangular acquisition range is half a nine-column lawn (4.5*80 pixels).
a=find(P,'PrimalPeashooterDefault')['Actions'][0];a['TriggerType']='rect';a['RectTriggerRange']={'mX':0,'mY':-40,'mWidth':360,'mHeight':60};find(PR,'PrimalPeashooterPea')['KnockbackChance']=0.75
report['primal_pea']={'knockback_chance':0.75,'acquisition_width_pixels':360,'grid_columns':4.5,'plantfood_unchanged':True,'projectile_flight_not_clipped':True}
prop('PrimalWallnutDefault','SmashDamage',1000)
stat('primalpotatomine','PrimalPotatomineDefault','TimeUntilArmed',10.0,'PrimalPotatoMine_ArmingTime')
for x in find(P,'PrimalPotatomineDefault')['PlantStats']:
 if x.get('Type')=='area':x['Value']='square'
prop('NightshadeDefault','LeafRespawnCooldown',3.5)
# Check existing Paladin equipment order against the native damage iteration order.
z=find(sheets['ZOMBIEPROPERTIES'],'ZombieDarkArmor4Default');assert z['ZombieArmorProps']==['RTID(DarkGiltDefault@ArmorTypes)','RTID(PaladinSuitDefault@ArmorTypes)'];arm=sheets['ARMORTYPES'];head=find(arm,'DarkGiltDefault');body=find(arm,'PaladinSuitDefault');assert head['BaseHealth']==2200 and body['BaseHealth']==300 and z['Hitpoints']==190
assert not set(head['ArmorFlags'])&{'passdamage','invincible'} and not set(body['ArmorFlags'])&{'passdamage','invincible'}
report['paladin_damage_order']={'order':['helmet:2200','body_armor:300','body:190'],'native_function':'0xc88898 iterates armor vector from index zero and passes remaining damage to next component, then body','native_v5_grants_helmet_before_suit':True,'bypass_armor_special_attacks_keep_native_rules':True}
# Update the visible explanation without escaped newline literals.
for k in p:
 if k.startswith('PACKAGES\\LAWNSTRINGS-'):
  d=dec(p[k]);v=d['objects'][0]['objdata']['LocStringValues'];name='ZOMBIE_DARK_ARMOR4_DESCRIPTION_HEADER';v[v.index(name)+1]='Body health: 190. Helmet armor: 2200. Body armor: 300. Ordinary damage hits the helmet first, then body armor, then the zombie. Magnet-shroom cannot remove either piece.';p[k]=encode(d)
for sheet,d in sheets.items():
 if d!=original[sheet]:
  key='PACKAGES\\'+sheet+'.RTON';p[key]=encode(d);assert dec(p[key])==d
# Speed up the actual Bonk Choy animation clocks; retain every frame and punch event byte.
class RateReader(Reader):
 def sprite(self):
  save=self.p;self.st();self.st();rates.append(self.p);self.p=save;return super().sprite()
rates=[];bk='Overlay/Packet/PlantBonkchoy_Common.rsgp';raw=files.get(bk,(O/'Packet/PlantBonkchoy_Common.rsgp').read_bytes());bf=read_packet(raw);pamkey=next(k for k in bf if k.endswith('.PAM'));oldpam=bf[pamkey];pd=RateReader(oldpam).decode();patched=bytearray(oldpam);patched[8]=38
for off in rates:struct.pack_into('<i',patched,off,round(struct.unpack_from('<i',oldpam,off)[0]*1.25))
newpam=bytes(patched);newpd=Reader(newpam).decode();assert newpd['main']['frames']==pd['main']['frames'];assert newpd['images']==pd['images']
for old,new in zip(pd['sprites']+[pd['main']],newpd['sprites']+[newpd['main']]):assert old['frames']==new['frames'] and new['rate']==old['rate']*1.25
bf[pamkey]=newpam;files[bk]=packet([(n,b,None) for n,b in bf.items()]);assert read_packet(files[bk])==bf
report['bonkchoy']={'main_animation_rate_before':pd['main']['rate'],'after':newpd['main']['rate'],'speed_multiplier':1.25,'all_frames_and_punch_events_preserved':True,'damage_preserved':True,'animation_driven_attack_runtime_unverified':True}
files[pk]=packet([(n,b,None) for n,b in p.items()]);assert read_packet(files[pk])==p;assert all(lookup(files[pk],n) is not None for n in p)
allowed={'PLANTPROPERTIES','PLANTLEVELS','PROJECTILETYPES','POWERS'}
for k in p:
 if k not in ['PACKAGES\\'+s+'.RTON' for s in allowed] and not k.startswith('PACKAGES\\LAWNSTRINGS-'):assert p[k]==oldp[k]
report.update(tile_cost_sequence=[0,100,200,400,800,1600],laser_level_one_theoretical_dps_before=55/2.85,laser_level_one_theoretical_dps_after=40/1.8,laser_level_one_theoretical_dps_ratio=(40/1.8)/(55/2.85),primal_mine={'damage':1000,'radius_grid_widths':2.6,'intended_area':'5x5 using native radial area behavior; corner coverage needs game test','arming_seconds':10},all_unspecified_plant_objects_verified_below=True,all_sun_denominations_levels_rewards_pope_and_paladin_native_logic_preserved=True,native_library_version=5)
# Object-level allowlist prevents unrelated plants or plant-food properties from drifting.
allowed_props={'BloomerangDefault','MagnetShroomDefault','HypnoShroomDefault','BowlingBulbDefault','BananaDefault','EndurianDefault','StalliaDefault','PrimalWallnutDefault','CabbagepultDefault','ShadowPeashooterDefault','SplitpeaDefault','LaserBeanDefault','PowerPlantDefault','SunBeanDefault','HotPotatoDefault','CeleryStalkerDefault','PrimalPeashooterDefault','PrimalPotatomineDefault','NightshadeDefault'}
for old,new in zip(original['PLANTPROPERTIES']['objects'],P['objects']):
 if not set(old.get('aliases',[]))&allowed_props:assert old==new
allowed_levels={'bloomerang','magnetshroom','hypnoshroom','bowlingbulb','banana','endurian','stallia','primalwallnut','cabbagepult','shadowpeashooter','splitpea','laser_bean','powerplant','sunbean','celerystalker','primalpotatomine'}
for old,new in zip(original['PLANTLEVELS']['objects'],L['objects']):
 if not set(old.get('aliases',[]))&allowed_levels:assert old==new
 for row in old['objdata'].get('FloatStats',[]):
  if any(x in row.get('Name','').lower() for x in ['plantfood','plant_food','damagepf','damagepfreverse']):assert row in new['objdata'].get('FloatStats',[])
for old,new in zip(original['PROJECTILETYPES']['objects'],PR['objects']):
 if 'PrimalPeashooterPea' not in old.get('aliases',[]):assert old==new
for old,new in zip(original['POWERS']['objects'],PW['objects']):
 if not old['objdata'].get('TypeName','').startswith(('SunshroomGrowthLevel','PrimalPotatoMineDamageLvl')):assert old==new
notes='''本次主线平衡（指定费用、伤害与时间同步等级表）：
卷心菜2.5秒；回旋镖200阳光；暗豌普通及暗影伤害30，暗影每次命中5秒减速，不因穿透衰减，连续命中续减速。
菜问原生动画时钟×1.25，伤害及出拳事件保留；裂荚前25/后每发30，大招不动。
激光豆40伤害/1.8秒，一级理论DPS约比旧55伤害、2.7—3秒高15%。
瓷砖首个免费，之后100/200/400/800…；阳光菇各成长阶段等待40秒。
磁力菇、魅惑菇75阳光；阳光豆0.5阳光/损失1血，普通单只上限300。
保龄250；香蕉800（只改费用，原有9999秒冷却和40/20间隔异常保留）。热土豆融冰2秒。
榴莲175阳光、接触伤害30；滞留番薯50；芹菜1秒100伤害、缩回延迟1.5秒。
原豌击退75%，普通索敌限制前方360像素，约4.5格；已发射子弹不会在边界立即消失，大招不改。
原坚果100阳光、碾压承伤1000；原雷1000伤害、准备10秒，原生范围半径2.6格宽，按5×5规格扩大，四角实际判定仍需实机确认。
夜影龙葵叶片恢复3.5秒。
圣骑士原生普通伤害按头盔2200→铠甲300→本体190结算；穿甲等特殊攻击保留原版规则。
保留教皇举杖小图、机喷关前期减量、此前植物修改、阳光制度及v5库。
安装：完整合并Overlay，使用本包StructInfo重打OBB。已装v5库不必重新处理库；旧库用包内v5工具升级。重启游戏、新开关卡测试。
已完成RTON往返、RSGP索引、原生伤害流程与动画事件检查；未安卓实机验证，攻速、减速续时、范围边界仍待实测。
'''
for n in ['CURRENT-VERSION.txt','使用说明.txt','本次修改.txt']:files[n]=notes.encode()+b'\n\n'+files[n]
files['Mainline-Balance/validation.json']=json.dumps(report,ensure_ascii=False,indent=2).encode();files['Mainline-Balance/本次修改.txt']=notes.encode();files['Mainline-Balance/build_balance.py']=Path(__file__).read_bytes()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,b in before.items():
  if n not in [pk,bk,'CURRENT-VERSION.txt','使用说明.txt','本次修改.txt']:assert z.read(n)==b
(W/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(out,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest());print(json.dumps(report,ensure_ascii=False))
