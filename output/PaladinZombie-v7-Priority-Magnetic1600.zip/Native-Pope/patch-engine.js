(function(scope){
function hex(s){return Uint8Array.from(s.match(/../g),x=>parseInt(x,16));}
function eq(a,b){return a.length===b.length&&a.every((x,i)=>x===b[i]);}
function b64(s){return Uint8Array.from(atob(s),x=>x.charCodeAt(0));}
async function sha(a){return Array.from(new Uint8Array(await scope.crypto.subtle.digest('SHA-256',a)),x=>x.toString(16).padStart(2,'0')).join('');}
async function patchLibrary(input,r){
 const b=input instanceof Uint8Array?input:new Uint8Array(input);if(b.length!==r.file_size||!eq(b.subarray(0,6),new Uint8Array([127,69,76,70,2,1])))throw Error('不是对应版本的64位ELF库。');
 const v=new DataView(b.buffer,b.byteOffset,b.byteLength);if(v.getUint16(18,true)!==183)throw Error('只支持对应arm64-v8a库。');
 const old=hex(r.old_call),next=hex(r.new_call),p=b64(r.payload_base64),applied=eq(b.subarray(r.site,r.site+4),next);if(!applied&&!eq(b.subarray(r.site,r.site+4),old))throw Error('施法调用点不匹配，停止修改。');
 const f=b.slice(r.function_offset,r.function_offset+r.function_length);f.set(old,r.site-r.function_offset);if(await sha(f)!==r.function_sha256)throw Error('国王函数校验不匹配。');
 const extras=r.secondary_sites||[];let extraApplied=true;
 for(const q of extras){const a=hex(q.old_call),n=hex(q.new_call),cur=b.subarray(q.site,q.site+4);if(!eq(cur,a)&&!eq(cur,n)&&!(q.upgrade_calls||[]).some(s=>eq(cur,hex(s))))throw Error('加冕判定调用点不匹配。');extraApplied=extraApplied&&eq(cur,n);const fn=b.slice(q.function_offset,q.function_offset+q.function_length);fn.set(a,q.site-q.function_offset);if(await sha(fn)!==q.function_sha256)throw Error('加冕判定函数校验不匹配。');}
 const rx=Number(v.getBigUint64(r.rx_size_offset,true)),mem=Number(v.getBigUint64(r.rx_memsize_offset,true));if(rx!==mem||rx<r.minimum_rx_size||r.cave_offset+p.length>r.cave_limit)throw Error('可执行段布局不匹配。');
 const cave=b.subarray(r.cave_offset,r.cave_offset+p.length);if(applied&&eq(cave,p)&&extraApplied&&rx>=r.cave_offset+p.length)return {bytes:b.slice(),already:true,upgraded:false,input_sha256:await sha(b),output_sha256:await sha(b)};
 let upgraded=false;if(applied){upgraded=eq(cave,p)||(r.upgrade_from_payloads||[]).some(s=>{const prev=b64(s);return rx>=r.cave_offset+prev.length&&eq(cave.subarray(0,prev.length),prev)&&!cave.subarray(prev.length).some(x=>x!==0);});if(!upgraded)throw Error('已有补丁不一致，停止保护当前库。');}
 else if(rx>r.cave_offset||cave.some(x=>x!==0))throw Error('预留区被其它补丁占用。');
 const out=b.slice();out.set(next,r.site);out.set(p,r.cave_offset);for(const q of extras)out.set(hex(q.new_call),q.site);const w=new DataView(out.buffer),end=BigInt(Math.max(rx,r.cave_offset+p.length));w.setBigUint64(r.rx_size_offset,end,true);w.setBigUint64(r.rx_memsize_offset,end,true);return {bytes:out,already:false,upgraded,input_sha256:await sha(b),output_sha256:await sha(out)};
}
scope.patchPopeV6Library=patchLibrary;if(typeof module!=='undefined')module.exports={patchLibrary};
})(globalThis);

(function(scope){
const unhex=s=>Uint8Array.from(s.match(/../g),x=>parseInt(x,16));
const eq=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]);
const un64=s=>Uint8Array.from(atob(s),x=>x.charCodeAt(0));
async function patchLibrary(input,r){
 let b=new Uint8Array(input instanceof Uint8Array?input:new Uint8Array(input)),seg=un64(r.segment_base64),already=false;
 if(b.length===r.append_offset+seg.length){
  const dv=new DataView(b.buffer,b.byteOffset,b.byteLength);
  if(Number(dv.getBigUint64(32,true))!==r.append_offset||dv.getUint16(56,true)!==9||!eq(b.subarray(r.append_offset),seg))throw Error('v7扩展段不匹配，停止修改。');
  for(const h of r.hooks)if(!eq(b.subarray(h.site,h.site+h.new.length/2),unhex(h.new)))throw Error('v7调用点不匹配。');
  if(b.subarray(r.base_file_size,r.append_offset).some(x=>x))throw Error('扩展填充区不匹配。');
  b=b.slice(0,r.base_file_size);const v=new DataView(b.buffer);v.setBigUint64(32,64n,true);v.setUint16(56,7,true);
  for(const h of r.hooks)b.set(unhex(h.old),h.site);already=true;
 }
 const checked=await scope.patchPopeV6Library(b,r.base_recipe);b=checked.bytes;
 if(!eq(b.subarray(64,64+7*56),un64(r.base_phdr_base64)))throw Error('ELF程序段布局不匹配。');
 for(const h of r.hooks)if(!eq(b.subarray(h.site,h.site+h.old.length/2),unhex(h.old)))throw Error('新功能调用点被其他补丁修改。');
 const out=new Uint8Array(r.append_offset+seg.length);out.set(b);out.set(seg,r.append_offset);
 for(const h of r.hooks)out.set(unhex(h.new),h.site);
 const v=new DataView(out.buffer);v.setBigUint64(32,BigInt(r.append_offset),true);v.setUint16(56,9,true);
 return {bytes:out,already,upgraded:true};
}
scope.patchPopeLibrary=patchLibrary;if(typeof module!=='undefined')module.exports={patchLibrary};
})(globalThis);
