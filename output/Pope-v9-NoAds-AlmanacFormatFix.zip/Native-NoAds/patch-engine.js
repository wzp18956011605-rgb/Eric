(function(scope){
const bytes=s=>Uint8Array.from(s.match(/../g),x=>parseInt(x,16)),eq=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
async function patchLibrary(input,r){const b=new Uint8Array(input);if(b.length<0x2000000||!eq(b.subarray(0,6),new Uint8Array([127,69,76,70,2,1]))||new DataView(b.buffer).getUint16(18,true)!==183)throw Error('请选择对应arm64-v8a/libPVZ2.so');let already=true;
for(const q of r.patches){const a=bytes(q.old),n=bytes(q.new),cur=b.subarray(q.site,q.site+a.length);if(!eq(cur,a)&&!eq(cur,n))throw Error(q.name+' 调用点不匹配，未修改文件');const c=b.slice(q.context_offset,q.context_offset+q.context_hex.length/2);c.set(a,q.site-q.context_offset);if(!eq(c,bytes(q.context_hex)))throw Error(q.name+' 上下文不匹配，未修改文件');already=already&&eq(cur,n);}
const out=b.slice();for(const q of r.patches)out.set(bytes(q.new),q.site);return {bytes:out,already};}
scope.patchNoAdsLibrary=patchLibrary;if(typeof module!=='undefined')module.exports={patchLibrary};})(globalThis);