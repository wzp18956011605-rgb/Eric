from pathlib import Path
import json,base64
R=json.loads(Path(__file__).with_name('magnet-recipe.json').read_text())
def normalize_magnet(data):
 r=R;off=r['append_offset'];a=base64.b64decode(r['old_segment_base64']);b=base64.b64decode(r['fixed_segment_base64'])
 if data[off:]==b:return data[:off]+a
 return data
def patch_magnet(data):
 r=R;off=r['append_offset'];a=base64.b64decode(r['old_segment_base64']);b=base64.b64decode(r['fixed_segment_base64'])
 if data[off:]==b:return data
 if data[off:]!=a:raise ValueError('教皇扩展段不匹配，停止修改磁力菇筛选')
 return data[:off]+b
