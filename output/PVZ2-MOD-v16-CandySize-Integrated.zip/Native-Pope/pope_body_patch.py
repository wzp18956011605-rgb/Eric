from pathlib import Path
import base64,json,struct,sys,hashlib
R=json.loads((Path(__file__).with_name('recipe.json')).read_text())
def patch_bytes(data):
 r=R;off=r['append_offset'];old=base64.b64decode(r['old_segment_base64']);new=base64.b64decode(r['new_segment_base64'])
 if len(data)!=off+len(old) or data[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',data,18)[0]!=183:raise ValueError('仅支持已安装v9/v9.1教皇补丁的对应ARM64库；请勿强行修改其他版本。')
 phoff=struct.unpack_from('<Q',data,32)[0];phnum=struct.unpack_from('<H',data,56)[0]
 if (phoff,phnum) not in [(64,7),(off,9)]:raise ValueError('ELF程序头布局不匹配')
 loads=[struct.unpack_from('<IIQQQQQQ',data,phoff+i*56) for i in range(phnum)]
 if not any(p[0]==1 and p[1]&1 and p[2]==off and p[3]==r['segment_va'] and p[5]>=len(old) for p in loads):raise ValueError('缺少匹配的v9可执行扩展段')
 for h in r['hooks']:
  n=bytes.fromhex(h['new']);a=h['site']
  if data[a:a+len(n)]!=n:raise ValueError('教皇调用点不匹配')
 if data[off:]==new:return data
 if data[off:]!=old:raise ValueError('已有教皇扩展段不是匹配的v9/v9.1版本，停止修改')
 return data[:off]+new
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('用法: python patch_pope.py 当前libPVZ2.so 输出libPVZ2.so')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'请保留原库，使用不同输出路径'
 out=patch_bytes(a.read_bytes());b.write_bytes(out);print('校验通过，输出SHA256:',hashlib.sha256(out).hexdigest())
