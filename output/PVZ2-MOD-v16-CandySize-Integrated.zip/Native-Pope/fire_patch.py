from pathlib import Path
import json,struct,hashlib
R=json.loads(Path(__file__).with_name('fire-recipe.json').read_text())
def patch_fire_bytes(data):
 r=R;site=r['site'];cave=r['cave'];old=bytes.fromhex(r['old_stub']);new=bytes.fromhex(r['new_stub']);br=bytes.fromhex(r['branch']);call=bytes.fromhex(r['old_call'])
 if len(data)<cave+len(new) or data[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',data,18)[0]!=183:raise ValueError('冰火补丁仅支持对应ARM64库')
 cur=data[site:site+4];stub=data[cave:cave+len(new)]
 fn=bytearray(data[r['function_offset']:r['function_offset']+r['function_length']]);q=site-r['function_offset'];fn[q:q+4]=call
 if hashlib.sha256(fn).hexdigest()!=r['function_sha256']:raise ValueError('火焰伤害函数校验不匹配')
 if not ((cur==call and not any(stub)) or (cur==br and stub in [old,new])):raise ValueError('冰火调用点或预留区被其他修改占用，停止修改')
 ph=struct.unpack_from('<Q',data,32)[0];num=struct.unpack_from('<H',data,56)[0];ok=False
 for i in range(num):
  p=struct.unpack_from('<IIQQQQQQ',data,ph+i*56)
  if p[0]==1 and p[1]&1 and p[2]<=cave and p[2]+p[5]>=cave+len(new) and p[3]+cave-p[2]==cave:ok=True
 if not ok:raise ValueError('冰火预留区未位于匹配的可执行段，停止修改')
 out=bytearray(data);out[site:site+4]=br;out[cave:cave+len(new)]=new;return bytes(out)
