from pathlib import Path
import struct,hashlib,base64,sys
RECIPE = {'file_size': 40569072, 'machine': 183, 'function_offset': 11796460, 'function_length': 2180, 'function_sha256': '087247d765ec69fbc14b714c57917e4466d4d47792a4f94d7fd40f9aed339b48', 'site': 11797548, 'old_call': 'd3020594', 'new_call': '352d6594', 'cave_offset': 38320384, 'cave_limit': 38320832, 'payload_base64': 'P0AAcUAAAFSc1Z8X83u8qfMDAKoBCIBSQuOfl/9/Aan/EwD5yAOAUuhDADmoAQAQCSlAqekTAfjqkwH44AMTquFDAJGX4J+XYAAAtCgAgFII1AA583vEqMADX9YAAAAARGFya0dpbHREZWZhdWx0AA==', 'payload_length': 112, 'minimum_rx_size': 38318716, 'rx_size_offset': 96, 'rx_memsize_offset': 104, 'armor_alias': 'DarkGiltDefault', 'target_helm_enum': 16, 'native_clear_helm': 13125152, 'native_add_armor': 13122464, 'runtime_tested': False}
def patch_bytes(b):
 r=RECIPE
 if len(b)!=r['file_size'] or b[:6]!=bytes([127,69,76,70,2,1]) or struct.unpack_from('<H',b,18)[0]!=183:raise ValueError('仅支持对应arm64-v8a ELF库')
 old=bytes.fromhex(r['old_call']);new=bytes.fromhex(r['new_call']);payload=base64.b64decode(r['payload_base64']);applied=b[r['site']:r['site']+4]==new
 if not applied and b[r['site']:r['site']+4]!=old:raise ValueError('调用点不匹配')
 check=bytearray(b[r['function_offset']:r['function_offset']+r['function_length']]);off=r['site']-r['function_offset'];check[off:off+4]=old
 if hashlib.sha256(check).hexdigest()!=r['function_sha256']:raise ValueError('国王函数校验不匹配')
 rx=struct.unpack_from('<Q',b,r['rx_size_offset'])[0];mem=struct.unpack_from('<Q',b,r['rx_memsize_offset'])[0]
 if rx!=mem or rx<r['minimum_rx_size']:raise ValueError('ELF可执行段布局不匹配')
 if applied:
  if b[r['cave_offset']:r['cave_offset']+len(payload)]!=payload or rx<r['cave_offset']+len(payload):raise ValueError('已有补丁不一致')
  return b
 if rx>r['cave_offset'] or any(b[r['cave_offset']:r['cave_offset']+len(payload)]):raise ValueError('预留区被占用，停止修改')
 out=bytearray(b);out[r['site']:r['site']+4]=new;out[r['cave_offset']:r['cave_offset']+len(payload)]=payload
 for off in [r['rx_size_offset'],r['rx_memsize_offset']]:struct.pack_into('<Q',out,off,r['cave_offset']+len(payload))
 return bytes(out)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('用法: python patch_pope.py 当前libPVZ2.so 输出libPVZ2.so')
 src,dst=map(Path,sys.argv[1:]);assert src.resolve()!=dst.resolve(),'请选择另一个输出路径保留原库';data=patch_bytes(src.read_bytes());dst.write_bytes(data);print('校验通过，输出SHA256:',hashlib.sha256(data).hexdigest())
