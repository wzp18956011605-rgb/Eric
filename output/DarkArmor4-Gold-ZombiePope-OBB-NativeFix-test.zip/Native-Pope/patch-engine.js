(function(scope){
function fromHex(s){return Uint8Array.from(s.match(/../g),x=>parseInt(x,16));}
function equal(a,b){return a.length===b.length&&a.every((x,i)=>x===b[i]);}
async function sha(a){return Array.from(new Uint8Array(await scope.crypto.subtle.digest('SHA-256',a)),x=>x.toString(16).padStart(2,'0')).join('');}
async function patchLibrary(input,r){
 const b=input instanceof Uint8Array?input:new Uint8Array(input);
 if(b.length!==r.file_size||!equal(b.subarray(0,6),new Uint8Array([127,69,76,70,2,1])))throw Error('不是对应版本的64位ELF库，未修改。');
 const v=new DataView(b.buffer,b.byteOffset,b.byteLength);if(v.getUint16(18,true)!==183)throw Error('只支持对应arm64-v8a库，不支持x86/armeabi-v7a。');
 const original=fromHex(r.old_call),replacement=fromHex(r.new_call),payload=Uint8Array.from(atob(r.payload_base64),x=>x.charCodeAt(0));
 const applied=equal(b.subarray(r.site,r.site+4),replacement);if(!applied&&!equal(b.subarray(r.site,r.site+4),original))throw Error('施法调用点不匹配；请提供当前库ZIP，不能强行修改。');
 const normalized=b.slice(r.function_offset,r.function_offset+r.function_length);normalized.set(original,r.site-r.function_offset);
 if(await sha(normalized)!==r.function_sha256)throw Error('国王施法函数校验不匹配，可能版本不同或已有冲突修改。');
 if(r.cave_offset+payload.length>r.cave_limit)throw Error('补丁区越界。');
 const rx=Number(v.getBigUint64(r.rx_size_offset,true)),mem=Number(v.getBigUint64(r.rx_memsize_offset,true));
 if(rx!==mem||rx<r.minimum_rx_size)throw Error('可执行段布局不匹配。');
 if(applied){if(!equal(b.subarray(r.cave_offset,r.cave_offset+payload.length),payload)||rx<r.cave_offset+payload.length)throw Error('已有补丁内容不一致。');return {bytes:b.slice(),already:true,input_sha256:await sha(b),output_sha256:await sha(b)};}
 if(rx>r.cave_offset||b.subarray(r.cave_offset,r.cave_offset+payload.length).some(x=>x!==0))throw Error('预留区被其它补丁占用，已停止保护原库。');
 const out=b.slice();out.set(replacement,r.site);out.set(payload,r.cave_offset);const w=new DataView(out.buffer);w.setBigUint64(r.rx_size_offset,BigInt(r.cave_offset+payload.length),true);w.setBigUint64(r.rx_memsize_offset,BigInt(r.cave_offset+payload.length),true);
 return {bytes:out,already:false,input_sha256:await sha(b),output_sha256:await sha(out)};
}
scope.patchPopeLibrary=patchLibrary;if(typeof module!=='undefined')module.exports={patchLibrary};
})(globalThis);
