from pathlib import Path
import sys,json,struct
R=json.loads(Path(__file__).with_name('v28p4-recipe.json').read_text())
def patch_bytes(data):
 if data[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',data,18)[0]!=183:raise ValueError('需要配套ARM64 libPVZ2.so')
 if len(data)!=R['file_size']:raise ValueError('库大小不匹配：需要当前26版配套库（27至28.3一直沿用它）')
 for g in R['guards']:
  if data[g['offset']:g['offset']+4].hex()!=g['value']:raise ValueError('26版已有火豆代码不匹配，停止处理')
 if all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))].hex()==e['new'] for e in R['edits']):return data
 for e in R['edits']:
  if data[e['offset']:e['offset']+len(bytes.fromhex(e['old']))].hex()!=e['old']:raise ValueError('调用点或空闲代码区不匹配，停止处理')
 out=bytearray(data)
 for e in R['edits']:out[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]=bytes.fromhex(e['new'])
 return bytes(out)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python patch_v28p4.py 当前libPVZ2.so 输出libPVZ2.so')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'输出不能覆盖输入';b.write_bytes(patch_bytes(a.read_bytes()));print('28.4长城专用草坪层修正完成')
