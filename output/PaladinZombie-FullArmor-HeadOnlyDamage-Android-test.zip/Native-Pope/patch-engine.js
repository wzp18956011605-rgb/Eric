(function(scope){
function hex(s){return Uint8Array.from(s.match(/../g),x=>parseInt(x,16));}
function eq(a,b){return a.length===b.length&&a.every((x,i)=>x===b[i]);}
function b64(s){return Uint8Array.from(atob(s),x=>x.charCodeAt(0));}
async function sha(a){return Array.from(new Uint8Array(await scope.crypto.subtle.digest('SHA-256',a)),x=>x.toString(16).padStart(2,'0')).join('');}
async function patchLibrary(input,r){
 const b=input instanceof Uint8Array?input:new Uint8Array(input);if(b.length!==r.file_size||!eq(b.subarray(0,6),new Uint8Array([127,69,76,70,2,1])))throw Error('不是对应版本的64位ELF库。');
 const v=new DataView(b.buffer,b.byteOffset,b.byteLength);if(v.getUint16(18,true)!==183)throw Error('只支持对应arm64-v8a库。');
 const old=hex(r.old_call),next=hex(r.new_call),p=b64(r.payload_base64),applied=eq(b.subarray(r.site,r.site+4),next);if(!applied&&!eq(b.subarray(r.site,r.site+4),old))throw Error('施法调用点不匹配，停止修改。');
 const f=b.slice(r.function_offset,r.function_offset+r.function_length);f.set(old,r.site-r.function_offset);if(await sha(f)!==r.function_sha256)throw Error('国王函数校验不匹配。');
 const extras=r.secondary_sites||[];let extraApplied=true;
 for(const q of extras){const a=hex(q.old_call),n=hex(q.new_call),cur=b.subarray(q.site,q.site+4);if(!eq(cur,a)&&!eq(cur,n))throw Error('加冕判定调用点不匹配。');extraApplied=extraApplied&&eq(cur,n);const fn=b.slice(q.function_offset,q.function_offset+q.function_length);fn.set(a,q.site-q.function_offset);if(await sha(fn)!==q.function_sha256)throw Error('加冕判定函数校验不匹配。');}
 const rx=Number(v.getBigUint64(r.rx_size_offset,true)),mem=Number(v.getBigUint64(r.rx_memsize_offset,true));if(rx!==mem||rx<r.minimum_rx_size||r.cave_offset+p.length>r.cave_limit)throw Error('可执行段布局不匹配。');
 const cave=b.subarray(r.cave_offset,r.cave_offset+p.length);if(applied&&eq(cave,p)&&extraApplied&&rx>=r.cave_offset+p.length)return {bytes:b.slice(),already:true,upgraded:false,input_sha256:await sha(b),output_sha256:await sha(b)};
 let upgraded=false;if(applied){upgraded=eq(cave,p)||(r.upgrade_from_payloads||[]).some(s=>{const prev=b64(s);return rx>=r.cave_offset+prev.length&&eq(cave.subarray(0,prev.length),prev)&&!cave.subarray(prev.length).some(x=>x!==0);});if(!upgraded)throw Error('已有补丁不一致，停止保护当前库。');}
 else if(rx>r.cave_offset||cave.some(x=>x!==0))throw Error('预留区被其它补丁占用。');
 const out=b.slice();out.set(next,r.site);out.set(p,r.cave_offset);for(const q of extras)out.set(hex(q.new_call),q.site);const w=new DataView(out.buffer),end=BigInt(Math.max(rx,r.cave_offset+p.length));w.setBigUint64(r.rx_size_offset,end,true);w.setBigUint64(r.rx_memsize_offset,end,true);return {bytes:out,already:false,upgraded,input_sha256:await sha(b),output_sha256:await sha(out)};
}
scope.patchPopeLibrary=patchLibrary;if(typeof module!=='undefined')module.exports={patchLibrary};
})(globalThis);
