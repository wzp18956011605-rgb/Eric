from pathlib import Path
import sys,hashlib
from pope_body_patch import patch_bytes as body_patch
from fire_patch import patch_fire_bytes
def patch_bytes(data):return patch_fire_bytes(body_patch(data))
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('用法: python patch_pope.py 当前libPVZ2.so 新libPVZ2.so')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'请使用不同输出路径保留原库'
 out=patch_bytes(a.read_bytes());b.write_bytes(out);print('校验通过，SHA256:',hashlib.sha256(out).hexdigest())
