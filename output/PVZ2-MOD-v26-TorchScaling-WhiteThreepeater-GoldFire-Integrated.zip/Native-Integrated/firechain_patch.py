from pathlib import Path
import json,struct,base64,sys
R=json.loads(Path(__file__).with_name('fire-recipe.json').read_text())
def patch_bytes(data):
 r=R;off=r['append_offset'];oldlen=r['old_segment_size'];nlen=r['new_segment_size'];code=base64.b64decode(r['code_base64']);co=r['code_file_offset']
 if data[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',data,18)[0]!=183:raise ValueError('需要匹配的ARM64库')
 if len(data)==off+nlen:
  if data[co:]==code and all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]==bytes.fromhex(e['new']) for e in r['edits']):return data
  raise ValueError('已有第19版长度但内容不同')
 if len(data)!=off+oldlen:raise ValueError('请先应用配套第18版库修复；当前长度不匹配')
 prev=json.loads(Path(__file__).with_name('no-cheating-recipe.json').read_text())
 if data[prev['code_file_offset']:]!=base64.b64decode(prev['code_base64']):raise ValueError('no cheating扩展代码不匹配')
 for e in prev['edits']:
  p=e['offset'];v=bytes.fromhex(e['new'])
  if data[p:p+len(v)]!=v:raise ValueError('已有no cheating调用点不匹配')
 for e in r['edits']:
  p=e['offset'];v=bytes.fromhex(e['old'])
  if data[p:p+len(v)]!=v:raise ValueError('火豆调用点不匹配')
 out=bytearray(data);out.extend(b'\0'*(off+nlen-len(out)));out[co:]=code
 ph=struct.unpack_from('<Q',out,32)[0];num=struct.unpack_from('<H',out,56)[0];found=0
 if (ph,num) not in [(64,7),(off,9)]:raise ValueError('ELF布局不匹配')
 for j in range(num):
  p=ph+j*56;h=struct.unpack_from('<IIQQQQQQ',out,p)
  if h[0]==1 and h[2]==off and h[3]==0x2870000:
   if h[1]!=5 or h[5]!=oldlen or h[6]!=oldlen:raise ValueError('扩展段权限/长度不匹配')
   struct.pack_into('<QQ',out,p+32,nlen,nlen);found+=1
 if found!=1:raise ValueError('无法唯一定位扩展段')
 for e in r['edits']:
  p=e['offset'];v=bytes.fromhex(e['new']);out[p:p+len(v)]=v
 return bytes(out)
if __name__=='__main__':
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve();b.write_bytes(patch_bytes(a.read_bytes()));print('第19版火豆库生成成功')
