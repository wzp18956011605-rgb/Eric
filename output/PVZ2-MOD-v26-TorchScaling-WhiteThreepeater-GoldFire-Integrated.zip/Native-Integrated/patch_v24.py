from pathlib import Path
import sys,json,struct
sys.path.insert(0,str(Path(__file__).parent))
from patch_v23 import patch_bytes as prior
R=json.loads(Path(__file__).with_name('v24-recipe.json').read_text())
def rw(data,expected,new):
 d=bytearray(data);ph=struct.unpack_from('<Q',d,32)[0];num=struct.unpack_from('<H',d,56)[0];found=0
 for j in range(num):
  p=ph+j*56;h=struct.unpack_from('<IIQQQQQQ',d,p)
  if h[0]==1 and h[1]==6 and h[3]==R['rw_memory']['segment_va']:
   if h[6]!=expected:raise ValueError('粉火触发记录区的BSS布局不匹配')
   struct.pack_into('<Q',d,p+40,new);found+=1
 if found!=1:raise ValueError('未找到唯一匹配的RW段')
 return bytes(d)
def patch_bytes(data):
 edits=R['edits'];mem=R['rw_memory']
 if all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]==bytes.fromhex(e['new']) for e in edits):
  d=bytearray(data)
  for e in edits:d[e['offset']:e['offset']+len(bytes.fromhex(e['old']))]=bytes.fromhex(e['old'])
  data=rw(bytes(d),mem['new'],mem['old'])
 data=prior(data)
 for e in edits:
  p=e['offset'];b=bytes.fromhex(e['old'])
  if data[p:p+len(b)]!=b:raise ValueError('第24版调用点不匹配：0x%x'%p)
 d=bytearray(data)
 for e in edits:d[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]=bytes.fromhex(e['new'])
 return rw(bytes(d),mem['old'],mem['new'])
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python patch_v24.py 当前库 输出库')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve();b.write_bytes(patch_bytes(a.read_bytes()));print('第24版整合库生成成功')
