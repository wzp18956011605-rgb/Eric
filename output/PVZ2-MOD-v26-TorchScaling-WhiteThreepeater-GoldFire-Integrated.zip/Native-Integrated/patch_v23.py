from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent))
from patch_v22 import patch_bytes as prior
R=json.loads(Path(__file__).with_name('v23-recipe.json').read_text())
def patch_bytes(data):
 edits=R['edits']
 if all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]==bytes.fromhex(e['new']) for e in edits):
  d=bytearray(data)
  for e in edits:d[e['offset']:e['offset']+len(bytes.fromhex(e['old']))]=bytes.fromhex(e['old'])
  data=bytes(d)
 data=prior(data)
 for e in edits:
  p=e['offset'];b=bytes.fromhex(e['old'])
  if data[p:p+len(b)]!=b:raise ValueError('第23版调用点不匹配：0x%x'%p)
 d=bytearray(data)
 for e in edits:d[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]=bytes.fromhex(e['new'])
 return bytes(d)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python patch_v23.py 当前库 输出库')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve();b.write_bytes(patch_bytes(a.read_bytes()));print('第23版整合库生成成功')
