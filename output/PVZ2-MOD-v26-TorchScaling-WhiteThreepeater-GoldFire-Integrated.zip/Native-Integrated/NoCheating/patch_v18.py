from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent/'PriorRepair'))
from patch_pope import patch_bytes as prior_patch
from cheating_patch import patch_bytes,R
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python patch_v18.py 当前libPVZ2.so 新libPVZ2.so')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'请保留原库'
 d=a.read_bytes()
 if len(d)!=R['append_offset']+R['new_segment_size']:d=prior_patch(d)
 b.write_bytes(patch_bytes(d));print('第18版cheating库生成成功')
