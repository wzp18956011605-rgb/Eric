from pathlib import Path
import json,struct,base64,sys
R=json.loads(Path(__file__).with_name('cheating-recipe.json').read_text())
def patch_bytes(data):
 if data[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',data,18)[0]!=183:raise ValueError('需要匹配的ARM64 libPVZ2.so')
 off=R['append_offset'];oldlen=R['old_segment_size'];newlen=R['new_segment_size'];code=base64.b64decode(R['code_base64']);expectedlen=off+newlen
 if len(data)==expectedlen:
  if data[R['code_file_offset']:]==code and all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]==bytes.fromhex(e['new']) for e in R['edits']):return data
  prev=json.loads(Path(__file__).with_name('previous-recipe.json').read_text())
  if data[prev['code_file_offset']:]!=base64.b64decode(prev['code_base64']) or not all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]==bytes.fromhex(e['new']) for e in prev['edits']):raise ValueError('已有扩展段不属于匹配的第17/18版')
  restored=bytearray(data[:off+oldlen])
  for e in prev['edits']:
   p=e['offset'];v=bytes.fromhex(e['old']);restored[p:p+len(v)]=v
  ph=struct.unpack_from('<Q',restored,32)[0];num=struct.unpack_from('<H',restored,56)[0]
  for j in range(num):
   p=ph+j*56
   if struct.unpack_from('<I',restored,p)[0]==1 and struct.unpack_from('<Q',restored,p+8)[0]==off:struct.pack_into('<QQ',restored,p+32,oldlen,oldlen)
  data=bytes(restored)
 if len(data)!=off+oldlen:raise ValueError('库长度不匹配：仅接受第14/15/16版配套库；请先用配套修复工具处理当前库')
 # Require the previously verified native Pope/magnet/fire segment unchanged.
 mr=json.loads(Path(__file__).with_name('magnet-recipe.json').read_text());expected=base64.b64decode(mr['fixed_segment_base64'])
 # Android-compatible version has different inactive stored program headers; compare executable body and ELF separately.
 if data[off+0x200:]!=expected[0x200:]:raise ValueError('教皇/磁力菇/冰火扩展段不是匹配的第14版内容')
 for e in R['edits']:
  b=bytes.fromhex(e['old']);p=e['offset']
  if data[p:p+len(b)]!=b:raise ValueError('调用点不匹配：'+e['purpose'])
 b=bytearray(data);b.extend(b'\0'*(expectedlen-len(b)));b[R['code_file_offset']:]=code
 phoff=struct.unpack_from('<Q',b,32)[0];phnum=struct.unpack_from('<H',b,56)[0]
 if (phoff,phnum) not in [(64,7),(off,9)]:raise ValueError('ELF程序头布局不匹配')
 found=0
 for p in [phoff+i*56 for i in range(phnum)]:
  h=struct.unpack_from('<IIQQQQQQ',b,p)
  if h[0]==1 and h[2]==off and h[3]==0x2870000:
   if h[1]!=5 or h[5]!=oldlen or h[6]!=oldlen:raise ValueError('扩展段权限/长度不匹配')
   struct.pack_into('<QQ',b,p+32,newlen,newlen);found+=1
 if found!=1:raise ValueError('无法唯一定位RX扩展段')
 for e in R['edits']:
  p=e['offset'];v=bytes.fromhex(e['new']);b[p:p+len(v)]=v
 return bytes(b)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python cheating_patch.py 当前libPVZ2.so 新libPVZ2.so')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'输出不能覆盖输入库'
 b.write_bytes(patch_bytes(a.read_bytes()));print('第18版cheating开关库生成成功')
