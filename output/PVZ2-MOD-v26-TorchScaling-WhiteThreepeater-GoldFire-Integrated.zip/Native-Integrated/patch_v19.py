from pathlib import Path
import sys
here=Path(__file__).parent
sys.path.insert(0,str(here/'NoCheating'/'PriorRepair'))
from patch_pope import patch_bytes as prior_patch
sys.path.insert(0,str(here/'NoCheating'))
from cheating_patch import patch_bytes as no_patch,R as NO_R
sys.path.insert(0,str(here))
from firechain_patch import patch_bytes,R
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python patch_v19.py 当前libPVZ2.so 输出libPVZ2.so')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'输出不能覆盖当前库'
 d=a.read_bytes()
 if len(d)!=R['append_offset']+R['new_segment_size']:
  if len(d)!=NO_R['append_offset']+NO_R['new_segment_size']:d=prior_patch(d)
  d=no_patch(d)
 b.write_bytes(patch_bytes(d));print('第19版整合库生成成功')
