from pathlib import Path
import sys,json
HERE=Path(__file__).parent
sys.path.insert(0,str(HERE))
from patch_v19 import prior_patch,no_patch,NO_R
from firechain_patch import patch_bytes as fire_patch,R as FIRE
R=json.loads((HERE/'v21-recipe.json').read_text())
def selected_edits(data):
 import hashlib,copy
 c=R['compat'];edits=copy.deepcopy(R['edits']);site=c['site'];current=data[site:site+4].hex();site_edit=next(e for e in edits if e['offset']==site)
 legacy=current==c['legacy_old'] or (current==site_edit['new'] and data[c['trampoline_offset']:c['trampoline_offset']+8].hex()==c['trampoline_new'])
 if legacy:
  p=c['cave_offset'];n=c['cave_length']
  if hashlib.sha256(data[p:p+n]).hexdigest()!=c['cave_sha256']:raise ValueError('旧糖弹补丁内容不匹配，停止处理')
  site_edit['old']=c['legacy_old'];next(e for e in edits if e['offset']==c['trampoline_offset'])['new']=c['trampoline_new']
 return edits

def patch_bytes(data):
 edits=selected_edits(data)
 if len(data)==R['size'] and all(data[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]==bytes.fromhex(e['new']) for e in edits):
  d=bytearray(data)
  for e in edits:d[e['offset']:e['offset']+len(bytes.fromhex(e['old']))]=bytes.fromhex(e['old'])
  data=bytes(d)
 if len(data)!=FIRE['append_offset']+FIRE['new_segment_size']:
  if len(data)!=NO_R['append_offset']+NO_R['new_segment_size']:data=prior_patch(data)
  data=no_patch(data)
 data=fire_patch(data)
 for e in edits:
  p=e['offset'];b=bytes.fromhex(e['old'])
  if data[p:p+len(b)]!=b:raise ValueError('第21版调用点不匹配：0x%x，期望%s，实际%s'%(p,b.hex(),data[p:p+len(b)].hex()))
 d=bytearray(data)
 for e in edits:d[e['offset']:e['offset']+len(bytes.fromhex(e['new']))]=bytes.fromhex(e['new'])
 return bytes(d)
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('python patch_v21.py 当前库 输出库')
 a,b=map(Path,sys.argv[1:]);assert a.resolve()!=b.resolve(),'输出不能覆盖输入';b.write_bytes(patch_bytes(a.read_bytes()));print('第21版整合库生成成功')
